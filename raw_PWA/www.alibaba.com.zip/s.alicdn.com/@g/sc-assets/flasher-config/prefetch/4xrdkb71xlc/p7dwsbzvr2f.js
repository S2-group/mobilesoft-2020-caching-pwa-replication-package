{
  "meta": {
    "type": "pageConfig",
    "namespace": "4xrdkb71xlc",
    "id": "p7dwsbzvr2f",
    "version": "2.1.0"
  },
  "template": {
    "parseAssets": true,
    "cacheFirst": true,
    "type": "html",
    "url": "https://sale.alibaba.com/super-september/2019sepsportsentertainment/index.html?ncms_static=true"
  },
  "apis": [],
  "assets": []
}