{
  "meta": {
    "version": "2.2.0",
    "type": "pageConfig",
    "namespace": "fkdazigrmmg",
    "id": "iyukxl7ysp",
    "generatedTime": 1562724726437
  },
  "template": {
    "parseAssets": true,
    "cacheFirst": true,
    "type": "html",
    "url": "https://www.alibaba.com/bulk"
  },
  "apis": [],
  "assets": []
}