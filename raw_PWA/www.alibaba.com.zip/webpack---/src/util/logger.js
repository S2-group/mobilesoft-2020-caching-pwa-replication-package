const logger = console || {
  log() {},
  warn() {},
  error() {},
};

export default logger;



// WEBPACK FOOTER //
// ./src/util/logger.js