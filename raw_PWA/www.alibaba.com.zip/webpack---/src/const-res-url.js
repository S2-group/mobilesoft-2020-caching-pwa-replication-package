export default '//g.alicdn.com/ife/acm/1.0.6/firebase.js';



// WEBPACK FOOTER //
// ./src/const-res-url.js